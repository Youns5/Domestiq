import { useEffect, useRef, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Send } from "lucide-react";
import { AppHeader, AppFooter } from "@/components/AppHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { cn } from "@/lib/utils";
import { initials } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/messages")({
  head: () => ({
    meta: [
      { title: "Messagerie — Domestiq" },
      {
        name: "description",
        content: "Échangez avec les professionnels avant et après une prestation à domicile.",
      },
      { property: "og:title", content: "Messagerie — Domestiq" },
      { property: "og:description", content: "Vos conversations Domestiq en un seul endroit." },
    ],
  }),
  component: MessagesPage,
});

type Conversation = {
  id: string;
  client_id: string;
  professional_id: string;
  last_message_at: string;
  professional_profiles: { id: string; first_name: string; last_name: string } | null;
};

type Message = {
  id: string;
  conversation_id: string;
  sender_id: string;
  body: string;
  created_at: string;
};

function MessagesPage() {
  const { userId } = useAuth();
  const queryClient = useQueryClient();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  const { data: conversations = [] } = useQuery({
    queryKey: ["conversations", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("conversations")
        .select("id, client_id, professional_id, last_message_at, professional_profiles(id, first_name, last_name)")
        .order("last_message_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as unknown as Conversation[];
    },
  });

  const currentId = activeId ?? conversations[0]?.id ?? null;

  const { data: messages = [] } = useQuery({
    queryKey: ["messages", currentId],
    enabled: !!currentId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("conversation_id", currentId!)
        .order("created_at");
      if (error) throw error;
      return (data ?? []) as Message[];
    },
  });

  useEffect(() => {
    if (!currentId) return;
    const channel = supabase
      .channel(`messages-${currentId}`)
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${currentId}` },
        () => queryClient.invalidateQueries({ queryKey: ["messages", currentId] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentId, queryClient]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages.length]);

  async function send(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim() || !currentId || !userId) return;
    const body = text.trim();
    setText("");
    await supabase.from("messages").insert({ conversation_id: currentId, sender_id: userId, body });
    await supabase
      .from("conversations")
      .update({ last_message_at: new Date().toISOString() })
      .eq("id", currentId);
    queryClient.invalidateQueries({ queryKey: ["messages", currentId] });
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Messagerie</h1>

        {conversations.length === 0 ? (
          <Card className="mt-8 glass">
            <CardContent className="p-8 text-center text-muted-foreground">
              Aucune conversation. Contactez un professionnel depuis sa fiche pour démarrer.
            </CardContent>
          </Card>
        ) : (
          <div className="mt-8 grid gap-4 md:grid-cols-[280px_1fr]">
            <Card>
              <CardContent className="p-2">
                {conversations.map((c) => {
                  const p = c.professional_profiles;
                  const name = p ? `${p.first_name} ${p.last_name}` : "Professionnel";
                  return (
                    <button
                      key={c.id}
                      onClick={() => setActiveId(c.id)}
                      className={cn(
                        "flex w-full items-center gap-3 rounded-xl px-3 py-3 text-left transition-colors hover:bg-secondary",
                        currentId === c.id && "bg-secondary",
                      )}
                    >
                      <span className="flex size-9 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                        {p ? initials(p.first_name, p.last_name) : "??"}
                      </span>
                      <span className="truncate text-sm font-medium">{name}</span>
                    </button>
                  );
                })}
              </CardContent>
            </Card>

            <Card className="flex min-h-[480px] flex-col">
              <CardContent className="flex flex-1 flex-col gap-3 p-5">
                <div className="flex-1 space-y-3 overflow-y-auto">
                  {messages.map((m) => (
                    <div
                      key={m.id}
                      className={cn(
                        "max-w-[75%] rounded-2xl px-4 py-2 text-sm",
                        m.sender_id === userId
                          ? "ml-auto bg-primary text-primary-foreground"
                          : "bg-secondary text-foreground",
                      )}
                    >
                      {m.body}
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>
                <form className="flex gap-2" onSubmit={send}>
                  <Input
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    placeholder="Écrire un message…"
                    aria-label="Message"
                  />
                  <Button type="submit" className="rounded-full" aria-label="Envoyer">
                    <Send className="size-4" />
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
      <AppFooter />
    </div>
  );
}
