
CREATE TYPE public.app_role AS ENUM ('admin','moderator','user');
CREATE TYPE public.account_type AS ENUM ('particulier','professionnel');
CREATE TYPE public.booking_status AS ENUM ('pending','confirmed','refused','completed','cancelled');
CREATE TYPE public.report_status AS ENUM ('open','reviewing','resolved','dismissed');

CREATE OR REPLACE FUNCTION public.set_updated_at() RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$ LANGUAGE plpgsql SET search_path = public;

CREATE TABLE public.profiles (
  id UUID PRIMARY KEY,
  first_name TEXT NOT NULL DEFAULT '',
  last_name TEXT NOT NULL DEFAULT '',
  email TEXT,
  phone TEXT,
  city TEXT,
  postal_code TEXT,
  avatar_url TEXT,
  account_type public.account_type NOT NULL DEFAULT 'particulier',
  suspended BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  role public.app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role);
$$;

CREATE POLICY "roles_select_own" ON public.user_roles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));

CREATE POLICY "profiles_select" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "profiles_insert_own" ON public.profiles FOR INSERT TO authenticated WITH CHECK (id = auth.uid());
CREATE POLICY "profiles_update_own" ON public.profiles FOR UPDATE TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE OR REPLACE FUNCTION public.handle_new_user() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, first_name, last_name, email, account_type)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'first_name',''),
    COALESCE(NEW.raw_user_meta_data->>'last_name',''),
    NEW.email,
    COALESCE((NEW.raw_user_meta_data->>'account_type')::public.account_type,'particulier')
  ) ON CONFLICT (id) DO NOTHING;
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id,'user') ON CONFLICT DO NOTHING;
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  emoji TEXT NOT NULL DEFAULT '✨',
  sort_order INT NOT NULL DEFAULT 0
);
GRANT SELECT ON public.categories TO anon, authenticated;
GRANT ALL ON public.categories TO service_role;
ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "categories_public_read" ON public.categories FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "categories_admin_write" ON public.categories FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

CREATE TABLE public.professional_profiles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE,
  first_name TEXT NOT NULL,
  last_name TEXT NOT NULL,
  category_id UUID REFERENCES public.categories(id),
  headline TEXT NOT NULL DEFAULT '',
  bio TEXT NOT NULL DEFAULT '',
  city TEXT NOT NULL DEFAULT '',
  postal_code TEXT,
  radius_km INT NOT NULL DEFAULT 10,
  hourly_rate NUMERIC(6,2) NOT NULL DEFAULT 20,
  min_hours NUMERIC(3,1) NOT NULL DEFAULT 1,
  experience_years INT NOT NULL DEFAULT 0,
  languages TEXT[] NOT NULL DEFAULT ARRAY['Français'],
  avatar_key TEXT,
  verified BOOLEAN NOT NULL DEFAULT false,
  published BOOLEAN NOT NULL DEFAULT true,
  rating NUMERIC(2,1) NOT NULL DEFAULT 0,
  reviews_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.professional_profiles TO authenticated;
GRANT SELECT ON public.professional_profiles TO anon;
GRANT ALL ON public.professional_profiles TO service_role;
ALTER TABLE public.professional_profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "pro_public_read" ON public.professional_profiles FOR SELECT TO anon, authenticated USING (published = true);
CREATE POLICY "pro_owner_read" ON public.professional_profiles FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "pro_owner_insert" ON public.professional_profiles FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "pro_owner_update" ON public.professional_profiles FOR UPDATE TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (user_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE TRIGGER pro_updated BEFORE UPDATE ON public.professional_profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.services (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.services TO authenticated;
GRANT SELECT ON public.services TO anon;
GRANT ALL ON public.services TO service_role;
ALTER TABLE public.services ENABLE ROW LEVEL SECURITY;
CREATE POLICY "services_public_read" ON public.services FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "services_owner_write" ON public.services FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid()));

CREATE TABLE public.availability (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  professional_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  weekday INT NOT NULL CHECK (weekday BETWEEN 0 AND 6),
  start_time TIME NOT NULL DEFAULT '09:00',
  end_time TIME NOT NULL DEFAULT '18:00',
  available BOOLEAN NOT NULL DEFAULT true,
  UNIQUE (professional_id, weekday)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.availability TO authenticated;
GRANT SELECT ON public.availability TO anon;
GRANT ALL ON public.availability TO service_role;
ALTER TABLE public.availability ENABLE ROW LEVEL SECURITY;
CREATE POLICY "avail_public_read" ON public.availability FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "avail_owner_write" ON public.availability FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid()));

CREATE TABLE public.bookings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL,
  professional_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  service TEXT NOT NULL,
  scheduled_date DATE NOT NULL,
  start_time TIME NOT NULL,
  duration_hours NUMERIC(3,1) NOT NULL DEFAULT 2,
  address TEXT NOT NULL DEFAULT '',
  notes TEXT,
  price NUMERIC(8,2) NOT NULL DEFAULT 0,
  status public.booking_status NOT NULL DEFAULT 'pending',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.bookings TO authenticated;
GRANT ALL ON public.bookings TO service_role;
ALTER TABLE public.bookings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "bookings_read" ON public.bookings FOR SELECT TO authenticated
  USING (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid())
    OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "bookings_insert_client" ON public.bookings FOR INSERT TO authenticated WITH CHECK (client_id = auth.uid());
CREATE POLICY "bookings_update" ON public.bookings FOR UPDATE TO authenticated
  USING (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid())
    OR public.has_role(auth.uid(),'admin'))
  WITH CHECK (true);
CREATE TRIGGER bookings_updated BEFORE UPDATE ON public.bookings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

CREATE TABLE public.conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id UUID NOT NULL,
  professional_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  last_message_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (client_id, professional_id)
);
GRANT SELECT, INSERT, UPDATE ON public.conversations TO authenticated;
GRANT ALL ON public.conversations TO service_role;
ALTER TABLE public.conversations ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.is_conversation_member(_conversation_id UUID, _user_id UUID)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.conversations c
    LEFT JOIN public.professional_profiles p ON p.id = c.professional_id
    WHERE c.id = _conversation_id AND (c.client_id = _user_id OR p.user_id = _user_id)
  );
$$;

CREATE POLICY "conv_read" ON public.conversations FOR SELECT TO authenticated
  USING (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid()));
CREATE POLICY "conv_insert" ON public.conversations FOR INSERT TO authenticated WITH CHECK (client_id = auth.uid());
CREATE POLICY "conv_update" ON public.conversations FOR UPDATE TO authenticated
  USING (client_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.professional_profiles p WHERE p.id = professional_id AND p.user_id = auth.uid()))
  WITH CHECK (true);

CREATE TABLE public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES public.conversations(id) ON DELETE CASCADE,
  sender_id UUID NOT NULL,
  body TEXT NOT NULL,
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "msg_read" ON public.messages FOR SELECT TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "msg_insert" ON public.messages FOR INSERT TO authenticated
  WITH CHECK (sender_id = auth.uid() AND public.is_conversation_member(conversation_id, auth.uid()));
CREATE POLICY "msg_update" ON public.messages FOR UPDATE TO authenticated
  USING (public.is_conversation_member(conversation_id, auth.uid())) WITH CHECK (true);
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;

CREATE TABLE public.reviews (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id UUID UNIQUE REFERENCES public.bookings(id) ON DELETE SET NULL,
  professional_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  client_id UUID,
  author_name TEXT NOT NULL DEFAULT 'Client',
  rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment TEXT NOT NULL DEFAULT '',
  flagged BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.reviews TO authenticated;
GRANT SELECT ON public.reviews TO anon;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews_public_read" ON public.reviews FOR SELECT TO anon, authenticated USING (flagged = false);
CREATE POLICY "reviews_admin_all" ON public.reviews FOR ALL TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));
CREATE POLICY "reviews_insert_completed" ON public.reviews FOR INSERT TO authenticated
  WITH CHECK (client_id = auth.uid() AND EXISTS (
    SELECT 1 FROM public.bookings b WHERE b.id = booking_id AND b.client_id = auth.uid()
      AND b.professional_id = professional_id AND b.status = 'completed'));

CREATE OR REPLACE FUNCTION public.refresh_pro_rating() RETURNS TRIGGER
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE pid UUID;
BEGIN
  pid := COALESCE(NEW.professional_id, OLD.professional_id);
  UPDATE public.professional_profiles p SET
    rating = COALESCE((SELECT ROUND(AVG(r.rating)::numeric,1) FROM public.reviews r WHERE r.professional_id = pid AND r.flagged = false),0),
    reviews_count = (SELECT COUNT(*) FROM public.reviews r WHERE r.professional_id = pid AND r.flagged = false)
  WHERE p.id = pid;
  RETURN NULL;
END; $$;
CREATE TRIGGER reviews_rating AFTER INSERT OR UPDATE OR DELETE ON public.reviews
FOR EACH ROW EXECUTE FUNCTION public.refresh_pro_rating();

CREATE TABLE public.favorites (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  professional_id UUID NOT NULL REFERENCES public.professional_profiles(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, professional_id)
);
GRANT SELECT, INSERT, DELETE ON public.favorites TO authenticated;
GRANT ALL ON public.favorites TO service_role;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
CREATE POLICY "fav_own" ON public.favorites FOR ALL TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL DEFAULT '',
  kind TEXT NOT NULL DEFAULT 'info',
  read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "notif_own" ON public.notifications FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "notif_insert" ON public.notifications FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "notif_update_own" ON public.notifications FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (true);
CREATE POLICY "notif_delete_own" ON public.notifications FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE TABLE public.reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id UUID NOT NULL,
  target_type TEXT NOT NULL,
  target_id UUID,
  reason TEXT NOT NULL,
  details TEXT,
  status public.report_status NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.reports TO authenticated;
GRANT ALL ON public.reports TO service_role;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reports_insert" ON public.reports FOR INSERT TO authenticated WITH CHECK (reporter_id = auth.uid());
CREATE POLICY "reports_read" ON public.reports FOR SELECT TO authenticated
  USING (reporter_id = auth.uid() OR public.has_role(auth.uid(),'admin'));
CREATE POLICY "reports_admin_update" ON public.reports FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

INSERT INTO public.categories (slug, name, emoji, sort_order) VALUES
 ('menage','Ménage','🧹',1),
 ('garde-enfants','Garde d''enfants','👶',2),
 ('aide-devoirs','Aide aux devoirs','📚',3),
 ('jardinage','Jardinage','🌳',4),
 ('bricolage','Bricolage','������',5),
 ('garde-animaux','Garde d''animaux','🐕',6),
 ('nettoyage-auto','Nettoyage automobile','🚗',7),
 ('cours-particuliers','Cours particuliers','🎓',8);

INSERT INTO public.professional_profiles
 (id, first_name, last_name, category_id, headline, bio, city, postal_code, radius_km, hourly_rate, min_hours, experience_years, languages, avatar_key, verified, rating, reviews_count)
VALUES
 ('11111111-1111-4111-8111-111111111101'::uuid,'Sarah','Martin',(SELECT id FROM public.categories WHERE slug='menage'),'Femme de ménage','Je m''occupe de l''entretien de votre logement avec rigueur et discrétion depuis 8 ans. Produits écologiques sur demande, repassage soigné et nettoyage des vitres.','Massy','91300',15,18,2,8,ARRAY['Français','Anglais'],'sarah',true,4.9,127),
 ('11111111-1111-4111-8111-111111111102'::uuid,'Karim','Benali',(SELECT id FROM public.categories WHERE slug='jardinage'),'Jardinier','Entretien de jardins, taille de haies, tonte et création d''espaces verts. Matériel professionnel fourni.','Palaiseau','91120',20,25,2,11,ARRAY['Français','Arabe'],'karim',true,4.8,89),
 ('11111111-1111-4111-8111-111111111103'::uuid,'Yann','Perrin',(SELECT id FROM public.categories WHERE slug='bricolage'),'Bricoleur','Montage de meubles, petites réparations, plomberie et électricité de base. Intervention rapide, devis clair.','Évry','91000',25,32,1,14,ARRAY['Français'],'yann',true,5.0,214),
 ('11111111-1111-4111-8111-111111111104'::uuid,'Léa','Bernard',(SELECT id FROM public.categories WHERE slug='garde-enfants'),'Baby-sitter','Étudiante en psychologie, expérience avec les enfants de 6 mois à 10 ans. Sorties d''école, bains, repas et jeux.','Antony','92160',10,15,2,4,ARRAY['Français','Espagnol'],'lea',true,4.9,64),
 ('11111111-1111-4111-8111-111111111105'::uuid,'Camille','Roux',(SELECT id FROM public.categories WHERE slug='aide-devoirs'),'Professeure particulière','Professeure de mathématiques, accompagnement du collège au lycée. Méthodologie, préparation aux examens.','Montrouge','92120',12,28,1,7,ARRAY['Français','Anglais'],'camille',false,4.7,41),
 ('11111111-1111-4111-8111-111111111106'::uuid,'Thomas','Girard',(SELECT id FROM public.categories WHERE slug='nettoyage-auto'),'Nettoyeur automobile','Lavage à domicile sans eau, rénovation intérieure et lustrage carrosserie. Véhicules particuliers et utilitaires.','Vitry-sur-Seine','94400',18,22,1,5,ARRAY['Français'],'thomas',true,4.6,58);

INSERT INTO public.services (professional_id, name)
SELECT '11111111-1111-4111-8111-111111111101'::uuid, s FROM unnest(ARRAY['Ménage','Repassage','Nettoyage des vitres']) s
UNION ALL SELECT '11111111-1111-4111-8111-111111111102'::uuid, s FROM unnest(ARRAY['Tonte de pelouse','Taille de haies','Entretien de jardin']) s
UNION ALL SELECT '11111111-1111-4111-8111-111111111103'::uuid, s FROM unnest(ARRAY['Montage de meubles','Petites réparations','Pose d''étagères']) s
UNION ALL SELECT '11111111-1111-4111-8111-111111111104'::uuid, s FROM unnest(ARRAY['Garde d''enfants','Sortie d''école','Aide aux devoirs']) s
UNION ALL SELECT '11111111-1111-4111-8111-111111111105'::uuid, s FROM unnest(ARRAY['Mathématiques','Physique-chimie','Méthodologie']) s
UNION ALL SELECT '11111111-1111-4111-8111-111111111106'::uuid, s FROM unnest(ARRAY['Lavage extérieur','Nettoyage intérieur','Lustrage']) s;

INSERT INTO public.availability (professional_id, weekday, start_time, end_time, available)
SELECT p.id, d.weekday, '09:00'::time, '18:00'::time, d.weekday <> 0
FROM public.professional_profiles p CROSS JOIN (SELECT generate_series(0,6) AS weekday) d;

INSERT INTO public.reviews (professional_id, author_name, rating, comment, created_at) VALUES
 ('11111111-1111-4111-8111-111111111101'::uuid,'Julie D.',5,'Sarah est ponctuelle et très minutieuse. L''appartement est impeccable à chaque passage.', now() - interval '9 days'),
 ('11111111-1111-4111-8111-111111111101'::uuid,'Marc L.',5,'Excellente prestation, je recommande sans hésiter.', now() - interval '24 days'),
 ('11111111-1111-4111-8111-111111111101'::uuid,'Nadia B.',4,'Très bon travail, un peu juste sur le repassage la première fois.', now() - interval '40 days'),
 ('11111111-1111-4111-8111-111111111102'::uuid,'Pierre M.',5,'Karim a redonné vie à mon jardin. Travail soigné et conseils utiles.', now() - interval '12 days'),
 ('11111111-1111-4111-8111-111111111102'::uuid,'Sophie R.',5,'Ponctuel et efficace, la haie est parfaite.', now() - interval '30 days'),
 ('11111111-1111-4111-8111-111111111103'::uuid,'Alexandre P.',5,'Montage de toute une cuisine en une matinée. Impressionnant.', now() - interval '5 days'),
 ('11111111-1111-4111-8111-111111111104'::uuid,'Claire T.',5,'Léa est douce et responsable, mes enfants l''adorent.', now() - interval '7 days'),
 ('11111111-1111-4111-8111-111111111105'::uuid,'Hugo F.',5,'Les notes de mon fils ont nettement progressé.', now() - interval '15 days'),
 ('11111111-1111-4111-8111-111111111106'::uuid,'Rachid K.',4,'Voiture comme neuve, prestation rapide.', now() - interval '3 days');

UPDATE public.professional_profiles p SET
  rating = COALESCE((SELECT ROUND(AVG(r.rating)::numeric,1) FROM public.reviews r WHERE r.professional_id = p.id),p.rating);
