// Favoris — équivalent de src/routes/_authenticated/favoris.tsx

let favUserId = null;

async function loadFavorites() {
  const { data, error } = await supabase
    .from("favorites")
    .select(`id, professional_id, professional_profiles(${PRO_FIELDS})`)
    .eq("user_id", favUserId);
  if (error) throw error;
  return data || [];
}

function renderFavorites(favorites) {
  document.getElementById("favorites-loading").style.display = "none";
  const empty = document.getElementById("favorites-empty");
  const grid = document.getElementById("favorites-grid");

  const valid = favorites.filter((f) => f.professional_profiles);
  if (valid.length === 0) {
    empty.style.display = "block";
    grid.innerHTML = "";
    return;
  }
  empty.style.display = "none";

  grid.innerHTML = valid
    .map((f) => {
      const p = f.professional_profiles;
      return `
      <div class="card fav-card">
        <div class="card-content">
          <div class="avatar-circle avatar-md">${esc(initials(p.first_name, p.last_name))}</div>
          <div style="flex:1">
            <a class="name" href="pro.html?id=${encodeURIComponent(p.id)}">${esc(p.first_name)} ${esc(p.last_name)}</a>
            <p class="headline">${esc(p.headline)}</p>
            <div class="meta">
              <span>${icon("star")} ${p.rating}</span>
              <span>${icon("mapPin")} ${esc(p.city)}</span>
              <span>${euro(Number(p.hourly_rate))}/h</span>
            </div>
          </div>
          <button type="button" class="btn btn-ghost btn-icon rounded-full fav-remove" aria-label="Retirer des favoris" data-remove="${esc(f.id)}">${icon("heart")}</button>
        </div>
      </div>`;
    })
    .join("");

  grid.querySelectorAll("[data-remove]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-remove");
      await supabase.from("favorites").delete().eq("id", id);
      const favorites = await loadFavorites();
      renderFavorites(favorites);
    });
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  const user = await requireAuth();
  if (!user) return;
  favUserId = user.id;

  try {
    const favorites = await loadFavorites();
    renderFavorites(favorites);
  } catch (err) {
    console.error(err);
    document.getElementById("favorites-loading").style.display = "none";
  }
});
