// Messagerie — équivalent de src/routes/_authenticated/messages.tsx

let msgUserId = null;
let conversations = [];
let activeConvId = null;
let currentChannel = null;

async function loadConversations() {
  const { data, error } = await supabase
    .from("conversations")
    .select(
      "id, client_id, professional_id, last_message_at, professional_profiles(id, first_name, last_name)",
    )
    .order("last_message_at", { ascending: false });
  if (error) throw error;
  return data || [];
}

async function loadMessages(conversationId) {
  const { data, error } = await supabase
    .from("messages")
    .select("*")
    .eq("conversation_id", conversationId)
    .order("created_at");
  if (error) throw error;
  return data || [];
}

function renderConversationList() {
  const list = document.getElementById("conversation-list");
  list.innerHTML = conversations
    .map((c) => {
      const p = c.professional_profiles;
      const name = p ? `${p.first_name} ${p.last_name}` : "Professionnel";
      const active = c.id === activeConvId;
      return `
      <button type="button" class="conv-item ${active ? "active" : ""}" data-conv="${esc(c.id)}">
        <span class="avatar-xs">${p ? esc(initials(p.first_name, p.last_name)) : "??"}</span>
        <span class="name">${esc(name)}</span>
      </button>`;
    })
    .join("");

  list.querySelectorAll("[data-conv]").forEach((btn) => {
    btn.addEventListener("click", () => selectConversation(btn.getAttribute("data-conv")));
  });
}

function renderMessages(messages) {
  const el = document.getElementById("chat-messages");
  el.innerHTML =
    messages
      .map(
        (m) =>
          `<div class="chat-bubble ${m.sender_id === msgUserId ? "mine" : "theirs"}">${esc(m.body)}</div>`,
      )
      .join("") + `<div id="chat-bottom"></div>`;
  document.getElementById("chat-bottom").scrollIntoView({ block: "end" });
}

async function selectConversation(id) {
  activeConvId = id;
  renderConversationList();

  if (currentChannel) {
    supabase.removeChannel(currentChannel);
    currentChannel = null;
  }

  const messages = await loadMessages(id);
  renderMessages(messages);

  currentChannel = supabase
    .channel(`messages-${id}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${id}` },
      async () => {
        const fresh = await loadMessages(id);
        renderMessages(fresh);
      },
    )
    .subscribe();
}

async function sendMessage(e) {
  e.preventDefault();
  const input = document.getElementById("chat-input");
  const text = input.value.trim();
  if (!text || !activeConvId || !msgUserId) return;
  input.value = "";

  await supabase.from("messages").insert({ conversation_id: activeConvId, sender_id: msgUserId, body: text });
  await supabase
    .from("conversations")
    .update({ last_message_at: new Date().toISOString() })
    .eq("id", activeConvId);

  const messages = await loadMessages(activeConvId);
  renderMessages(messages);
}

document.addEventListener("DOMContentLoaded", async () => {
  const user = await requireAuth();
  if (!user) return;
  msgUserId = user.id;

  document.getElementById("chat-form").addEventListener("submit", sendMessage);

  try {
    conversations = await loadConversations();
  } catch (err) {
    console.error(err);
    conversations = [];
  }

  document.getElementById("messages-loading").style.display = "none";

  if (conversations.length === 0) {
    document.getElementById("messages-empty").style.display = "block";
    return;
  }

  document.getElementById("messages-content").style.display = "grid";
  renderConversationList();
  await selectConversation(conversations[0].id);
});
