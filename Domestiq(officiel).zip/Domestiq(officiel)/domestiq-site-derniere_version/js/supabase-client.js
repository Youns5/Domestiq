// Configuration Supabase — mêmes valeurs que celles utilisées par le site
// d'origine (clé "publishable", volontairement publique côté navigateur).
const SUPABASE_URL = "https://c--b896b01e-fb32-41b5-9ec6-626907464de7-prod.lovable.cloud";
const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_txXW-nXoqkjTsMyZZVJ8Ow_fGK49vOQ";

const supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: { persistSession: true, autoRefreshToken: true },
});
