# Domestiq

Marketplace de services à domicile. Trouvez un professionnel vérifié près de chez
vous, échangez, réservez et évaluez en toute confiance.

## Stack

- **TanStack Start** (SSR) + **TanStack Router** + **TanStack Query**
- **React 19** + **Vite 8**
- **Tailwind CSS 4**
- **Supabase** (PostgreSQL, Auth, RLS, Realtime)

## Démarrage rapide

Prérequis : Node.js ≥ 22.12 (recommandé via [nvm](https://github.com/nvm-sh/nvm)).

```sh
git clone <this-repository-url>
cd <repository-name>
npm install
```

### Variables d'environnement

Copiez `.env.example` vers `.env` (`cp .env.example .env`) et renseignez vos
valeurs **Supabase**. Ne commitez jamais le fichier `.env`.

| Variable                        | Où ?                                    | Usage                                       |
| ------------------------------- | --------------------------------------- | ------------------------------------------- |
| `VITE_SUPABASE_URL`             | Client (build) + fichier `.env`         | URL du projet Supabase                      |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Client (build) + fichier `.env`         | Clé publiquable Supabase (sans secret)      |
| `SUPABASE_URL`                  | Serveur (SSR / Netlify functions)       | URL du projet Supabase                      |
| `SUPABASE_PUBLISHABLE_KEY`      | Serveur (SSR / Netlify functions)       | Clé publiquable Supabase                    |
| `SUPABASE_SERVICE_ROLE_KEY`     | Serveur (admin uniquement, optionnel)   | Clé de service — jamais exposée au client    |

Aucune clé secrète n'est exposée au navigateur : le client n'utilise que les
variables `VITE_*` (clé publiquable).

### Lancement

```sh
npm run dev        # serveur de développement (http://localhost:3000)
npm run build      # build de production
npm run preview    # prévisualisation du build
npm run lint       # lint eslint
npm run format     # formatage prettier
```

## Base de données

Le schéma Supabase (tables, RLS, triggers, fonctions SQL, données de démo) vit
dans `supabase/migrations/`. Restaurez-le sur votre projet via le CLI Supabase :

```sh
supabase link --project-ref <project-ref>
supabase db push
```

Ou importez le fichier SQL directement depuis le dashboard Supabase (SQL editor).

## Authentification

L'authentification est gérée par **Supabase Auth** (inscription, connexion,
confirmation par email, sessions). Aucune dépendance externe :

- la confirmation de compte redirige vers **l'origine courante**
  (`window.location.origin`), c'est-à-dire `localhost` en développement et le
  domaine Netlify en production ;
- configurez l'URL de redirection supérieure dans le dashboard Supabase
  (`Authentication → URL Configuration → Site URL` + `Redirect URLs`).

## Déploiement (Netlify + GitHub)

Le projet est prêt pour un déploiement Netlify.

1. Poussez le dépôt sur GitHub.
2. Sur Netlify : **Add new site → Import an existing project**, connectez le repo.
3. Netlify détecte automatiquement `netlify.toml` :
   - build : `npm run build`
   - publish directory : `dist/client`
   - le serveur SSR est déployé en Netlify function (`dist/server`) via le plugin
     `@netlify/vite-plugin-tanstack-start`.
4. Ajoutez les variables d'environnement (voir tableau ci-dessus) dans
   **Site configuration → Environment variables**.
5. Déployez.

La première colonne du tableau (variables `VITE_*`) doit être renseignée **au
moment du build** dans Netlify pour être injectée côté client.

## Résumé des opérations récentes

- **Nettoyage massif** : suppression de dépendances et composants inutilisés, UI simplifiée.
- **Lovable** : toutes les références à Lovable ont été enlevées du code source et de la documentation.
- **Build & vérifications** : `npm install` / `npm run build` exécutés avec succès ; SSR et prévisualisation testés.
- **TypeScript** : `tsc --noEmit` vérifié sans erreurs.
- **Routes testées** : `/` (200), `/recherche` (200), `/auth` (200), `/pro/:id` (ex. `/pro/1`) (200). ` /espace-pro` et `/admin` renvoient 404 si inexistantes.
- **Secrets** : le fichier `.env` contenant des clés réelles a été retiré du dépôt avant archivage.
- **Archive finale** : `Domestiq-officiel-clean.zip` créée sans `node_modules`, sans `.env`, sans `.git`, sans caches ni `dist` inutiles — taille : ~532K — emplacement : `/home/lucas/Téléchargements/Domestiq(officiel)/Domestiq-officiel-clean.zip`.

Si vous souhaitez que je prépare un commit/Git ou que je pousse l'archive sur GitHub, dites-moi où.

## Structure

```
src/
├── components/        # Composants d'application (AppHeader/Footer) + UI (shadcn)
├── hooks/             # Hooks métier (useAuth)
├── integrations/
│   └── supabase/      # Clients Supabase (client, client serveur, middleware auth)
├── lib/               # Utilitaires, erreurs, requêtes Supabase (queries)
└── routes/            # Routes TanStack (file-based routing)
public/                # Assets statiques
supabase/migrations/   # Schéma SQL (tables, RLS, triggers, seed)
```
