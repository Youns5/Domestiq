import { supabase } from "@/integrations/supabase/client";

export type Category = {
  id: string;
  slug: string;
  name: string;
  emoji: string;
  sort_order: number;
};

export type Pro = {
  id: string;
  user_id: string | null;
  first_name: string;
  last_name: string;
  category_id: string | null;
  headline: string;
  bio: string;
  city: string;
  hourly_rate: number;
  min_hours: number;
  experience_years: number;
  languages: string[];
  verified: boolean;
  rating: number;
  reviews_count: number;
  radius_km: number;
};

export const PRO_FIELDS =
  "id,user_id,first_name,last_name,category_id,headline,bio,city,hourly_rate,min_hours,experience_years,languages,verified,rating,reviews_count,radius_km";

export const categoriesQuery = {
  queryKey: ["categories"],
  queryFn: async (): Promise<Category[]> => {
    const { data, error } = await supabase
      .from("categories")
      .select("*")
      .order("sort_order");
    if (error) throw error;
    return data as Category[];
  },
};

export type ProFilters = {
  q?: string | undefined;
  category?: string | undefined;
  city?: string | undefined;
  maxRate?: number | undefined;
  minRating?: number | undefined;
  sort?: string | undefined;
};

export function prosQuery(filters: ProFilters) {
  return {
    queryKey: ["pros", filters],
    queryFn: async (): Promise<Pro[]> => {
      let req = supabase
        .from("professional_profiles")
        .select(PRO_FIELDS)
        .eq("published", true);

      if (filters.category) req = req.eq("category_id", filters.category);
      if (filters.city) req = req.ilike("city", `%${filters.city}%`);
      if (filters.maxRate) req = req.lte("hourly_rate", filters.maxRate);
      if (filters.minRating) req = req.gte("rating", filters.minRating);
      if (filters.q)
        req = req.or(
          `first_name.ilike.%${filters.q}%,last_name.ilike.%${filters.q}%,headline.ilike.%${filters.q}%,bio.ilike.%${filters.q}%`,
        );

      if (filters.sort === "price") req = req.order("hourly_rate", { ascending: true });
      else if (filters.sort === "experience")
        req = req.order("experience_years", { ascending: false });
      else req = req.order("rating", { ascending: false });

      const { data, error } = await req.limit(60);
      if (error) throw error;
      return data as Pro[];
    },
  };
}

export function proDetailQuery(id: string) {
  return {
    queryKey: ["pro", id],
    queryFn: async () => {
      const [pro, services, reviews, availability] = await Promise.all([
        supabase.from("professional_profiles").select(PRO_FIELDS).eq("id", id).maybeSingle(),
        supabase.from("services").select("*").eq("professional_id", id),
        supabase
          .from("reviews")
          .select("*")
          .eq("professional_id", id)
          .eq("flagged", false)
          .order("created_at", { ascending: false }),
        supabase.from("availability").select("*").eq("professional_id", id).order("weekday"),
      ]);
      if (pro.error) throw pro.error;
      return {
        pro: pro.data as Pro | null,
        services: services.data ?? [],
        reviews: reviews.data ?? [],
        availability: availability.data ?? [],
      };
    },
  };
}

export const WEEKDAYS = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

export const STATUS_LABELS: Record<string, string> = {
  pending: "En attente",
  confirmed: "Confirmée",
  refused: "Refusée",
  completed: "Terminée",
  cancelled: "Annulée",
};

export function euro(n: number) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n);
}

export function initials(first: string, last: string) {
  return `${first.charAt(0)}${last.charAt(0)}`.toUpperCase();
}
