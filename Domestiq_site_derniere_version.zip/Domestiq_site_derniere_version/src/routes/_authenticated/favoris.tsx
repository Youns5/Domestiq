import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Star, MapPin, Heart } from "lucide-react";
import { AppHeader, AppFooter } from "@/components/AppHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { euro, initials, PRO_FIELDS, type Pro } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/favoris")({
  head: () => ({
    meta: [
      { title: "Mes favoris — Domestiq" },
      {
        name: "description",
        content: "Retrouvez les professionnels que vous avez enregistrés sur Domestiq.",
      },
      { property: "og:title", content: "Mes favoris — Domestiq" },
      { property: "og:description", content: "Vos professionnels préférés, toujours à portée." },
    ],
  }),
  component: FavoritesPage,
});

function FavoritesPage() {
  const { userId } = useAuth();
  const queryClient = useQueryClient();

  const { data: favorites = [], isLoading } = useQuery({
    queryKey: ["favorites", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("favorites")
        .select(`id, professional_id, professional_profiles(${PRO_FIELDS})`)
        .eq("user_id", userId!);
      if (error) throw error;
      return (data ?? []) as unknown as Array<{
        id: string;
        professional_id: string;
        professional_profiles: Pro | null;
      }>;
    },
  });

  async function remove(favId: string) {
    await supabase.from("favorites").delete().eq("id", favId);
    queryClient.invalidateQueries({ queryKey: ["favorites", userId] });
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-5xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Mes favoris</h1>

        {isLoading && <p className="mt-8 text-muted-foreground">Chargement…</p>}

        {!isLoading && favorites.length === 0 && (
          <Card className="mt-8 glass">
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">Aucun professionnel enregistré pour l'instant.</p>
              <Button asChild className="mt-4 rounded-full">
                <Link to="/recherche">Parcourir les professionnels</Link>
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          {favorites.map((f) => {
            const p = f.professional_profiles;
            if (!p) return null;
            return (
              <Card key={f.id}>
                <CardContent className="flex gap-4 p-5">
                  <div className="flex size-14 shrink-0 items-center justify-center rounded-2xl bg-primary/10 font-display font-bold text-primary">
                    {initials(p.first_name, p.last_name)}
                  </div>
                  <div className="flex-1">
                    <Link
                      to="/pro/$id"
                      params={{ id: p.id }}
                      className="font-display text-lg font-semibold hover:underline"
                    >
                      {p.first_name} {p.last_name}
                    </Link>
                    <p className="text-sm text-muted-foreground">{p.headline}</p>
                    <div className="mt-2 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <Star className="size-4 fill-accent text-accent" />
                        {p.rating}
                      </span>
                      <span className="flex items-center gap-1">
                        <MapPin className="size-4" />
                        {p.city}
                      </span>
                      <span>{euro(Number(p.hourly_rate))}/h</span>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="rounded-full"
                    aria-label="Retirer des favoris"
                    onClick={() => remove(f.id)}
                  >
                    <Heart className="size-4 fill-primary text-primary" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </main>
      <AppFooter />
    </div>
  );
}
