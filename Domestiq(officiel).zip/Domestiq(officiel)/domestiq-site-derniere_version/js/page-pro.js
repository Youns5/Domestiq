// Fiche professionnel — équivalent de src/routes/pro.$id.tsx

let currentUserId = null;
let currentProId = null;
let currentPro = null;
let currentServices = [];
let isFavorite = null; // id de la ligne favorites, ou null

function renderNotFound() {
  document.getElementById("pro-loading").style.display = "none";
  document.getElementById("pro-not-found").style.display = "block";
}

function renderPro(data) {
  const { pro, services, reviews, availability } = data;
  currentPro = pro;
  currentServices = services;

  document.getElementById("pro-loading").style.display = "none";
  document.getElementById("pro-content").style.display = "grid";

  document.getElementById("pro-avatar").textContent = initials(pro.first_name, pro.last_name);
  document.getElementById("pro-name").innerHTML =
    `${esc(pro.first_name)} ${esc(pro.last_name)}` +
    (pro.verified ? `<span class="verified-badge">${icon("badgeCheck")}</span>` : "");
  document.getElementById("pro-headline").textContent = pro.headline;
  document.getElementById("pro-meta").innerHTML = `
    <span>${icon("star")} ${pro.rating} (${pro.reviews_count} avis)</span>
    <span>${icon("mapPin")} ${esc(pro.city)} · ${pro.radius_km} km</span>
    <span>${pro.experience_years} ans d'expérience</span>
  `;

  document.getElementById("pro-bio").textContent = pro.bio;
  document.getElementById("pro-languages").innerHTML = (pro.languages || [])
    .map((l) => `<span class="badge badge-secondary">${esc(l)}</span>`)
    .join("");

  document.getElementById("pro-services").innerHTML = services
    .map((s) => `<span class="badge badge-outline badge-pill">${esc(s.name)}</span>`)
    .join("");

  document.getElementById("pro-availability").innerHTML = availability
    .map(
      (a) =>
        `<li><span class="day">${WEEKDAYS[a.weekday]}</span> · ${a.available ? `${a.start_time.slice(0, 5)} – ${a.end_time.slice(0, 5)}` : "Indisponible"}</li>`,
    )
    .join("");

  document.getElementById("pro-reviews-title").textContent = `Avis (${reviews.length})`;
  const reviewsEl = document.getElementById("pro-reviews");
  if (reviews.length === 0) {
    reviewsEl.innerHTML = `<p style="font-size:.875rem;color:var(--muted-foreground)">Aucun avis pour le moment.</p>`;
  } else {
    reviewsEl.innerHTML = reviews
      .map(
        (r) => `
        <div class="review-item">
          <div class="row">
            <span class="author">${esc(r.author_name)}</span>
            <span class="stars">${icon("star")} ${r.rating}/5</span>
          </div>
          <p class="comment">${esc(r.comment)}</p>
        </div>`,
      )
      .join("");
  }

  document.getElementById("booking-price").innerHTML = `${euro(Number(pro.hourly_rate))}<span class="unit"> / heure</span>`;
  document.getElementById("booking-min").textContent = `Minimum ${pro.min_hours} h par intervention`;
  const serviceSelect = document.getElementById("booking-service");
  serviceSelect.innerHTML =
    `<option value="">Choisir…</option>` +
    services.map((s) => `<option value="${esc(s.name)}">${esc(s.name)}</option>`).join("");
  document.getElementById("booking-hours").min = String(pro.min_hours);
  document.getElementById("booking-hours").value = "2";
  updateBookingTotal();

  refreshFavoriteState();
}

function updateBookingTotal() {
  const hours = Number(document.getElementById("booking-hours").value || 0);
  const price = currentPro ? Number(currentPro.hourly_rate) * hours : 0;
  document.getElementById("booking-total-value").textContent = euro(price);
}

async function refreshFavoriteState() {
  const btn = document.getElementById("favorite-btn");
  if (!currentUserId) {
    isFavorite = null;
    btn.innerHTML = `${icon("heart")} Ajouter aux favoris`;
    return;
  }
  const { data } = await supabase
    .from("favorites")
    .select("id")
    .eq("professional_id", currentProId)
    .eq("user_id", currentUserId)
    .maybeSingle();
  isFavorite = data ? data.id : null;
  btn.innerHTML = isFavorite
    ? `${icon("heart", "fav-active")} Retiré des favoris`
    : `${icon("heart")} Ajouter aux favoris`;
}

async function toggleFavorite() {
  if (!currentUserId) {
    window.location.href = "auth.html";
    return;
  }
  if (isFavorite) {
    await supabase.from("favorites").delete().eq("id", isFavorite);
  } else {
    await supabase.from("favorites").insert({ user_id: currentUserId, professional_id: currentProId });
  }
  refreshFavoriteState();
}

async function startConversation() {
  if (!currentUserId) {
    window.location.href = "auth.html";
    return;
  }
  const { data: existing } = await supabase
    .from("conversations")
    .select("id")
    .eq("client_id", currentUserId)
    .eq("professional_id", currentProId)
    .maybeSingle();
  if (!existing) {
    const { error } = await supabase
      .from("conversations")
      .insert({ client_id: currentUserId, professional_id: currentProId });
    if (error) {
      toast.error("Impossible d'ouvrir la discussion.");
      return;
    }
  }
  window.location.href = "messages.html";
}

async function submitBooking(e) {
  e.preventDefault();
  if (!currentUserId) {
    window.location.href = "auth.html";
    return;
  }
  const service = document.getElementById("booking-service").value;
  const date = document.getElementById("booking-date").value;
  const startTime = document.getElementById("booking-time").value;
  const hours = Number(document.getElementById("booking-hours").value);
  const address = document.getElementById("booking-address").value;
  const notes = document.getElementById("booking-notes").value;

  if (!service || !date || !address) {
    toast.error("Merci de compléter la prestation, la date et l'adresse.");
    return;
  }

  const submitBtn = document.getElementById("booking-submit");
  submitBtn.disabled = true;
  submitBtn.textContent = "Envoi…";

  const price = Number(currentPro.hourly_rate) * hours;
  const { error } = await supabase.from("bookings").insert({
    client_id: currentUserId,
    professional_id: currentProId,
    service,
    scheduled_date: date,
    start_time: startTime,
    duration_hours: hours,
    address,
    notes,
    price,
  });

  submitBtn.disabled = false;
  submitBtn.textContent = "Demander une réservation";

  if (error) {
    toast.error("La réservation n'a pas pu être enregistrée.");
    return;
  }
  toast.success("Demande envoyée ! Le professionnel va la confirmer.");
  window.location.href = "tableau-de-bord.html";
}

document.addEventListener("DOMContentLoaded", async () => {
  currentProId = getSearchParams().get("id");
  if (!currentProId) {
    renderNotFound();
    return;
  }

  document.getElementById("favorite-btn").addEventListener("click", toggleFavorite);
  document.getElementById("contact-btn").addEventListener("click", startConversation);
  document.getElementById("booking-form").addEventListener("submit", submitBooking);
  document.getElementById("booking-hours").addEventListener("input", updateBookingTotal);

  supabase.auth.onAuthStateChange((_event, session) => {
    currentUserId = session ? session.user.id : null;
    if (currentPro) refreshFavoriteState();
  });
  const { data: sessionData } = await supabase.auth.getSession();
  currentUserId = sessionData.session ? sessionData.session.user.id : null;

  try {
    const data = await fetchProDetail(currentProId);
    if (!data.pro) {
      renderNotFound();
      return;
    }
    renderPro(data);
  } catch (err) {
    console.error(err);
    renderNotFound();
  }
});
