// Middleware côté client : attache le token d'accès Supabase aux appels de
// fonctions serveur (serverFn). Enregistré comme `functionMiddleware` global
// dans src/start.ts ; sans lui, le navigateur n'envoie jamais le bearer token.
import { createMiddleware } from '@tanstack/react-start'
import { supabase } from './client'

// Must be registered as a global `functionMiddleware` in `src/start.ts`; otherwise
// the browser never attaches the bearer token to serverFn RPCs.
export const attachSupabaseAuth = createMiddleware({ type: 'function' }).client(
  async ({ next }) => {
    const { data } = await supabase.auth.getSession()
    const token = data.session?.access_token
    return next({
      headers: token ? { Authorization: `Bearer ${token}` } : {},
    })
  },
)
