// Tableau de bord — équivalent de src/routes/_authenticated/tableau-de-bord.tsx

let dashUserId = null;

async function loadBookings() {
  const { data, error } = await supabase
    .from("bookings")
    .select("*")
    .eq("client_id", dashUserId)
    .order("scheduled_date", { ascending: false });
  if (error) throw error;
  return data || [];
}

function renderBookings(bookings) {
  document.getElementById("dashboard-loading").style.display = "none";
  const empty = document.getElementById("dashboard-empty");
  const list = document.getElementById("bookings-list");

  if (bookings.length === 0) {
    empty.style.display = "block";
    list.innerHTML = "";
    return;
  }
  empty.style.display = "none";

  list.innerHTML = bookings
    .map((b) => {
      const dateLabel = new Date(b.scheduled_date).toLocaleDateString("fr-FR", {
        weekday: "long",
        day: "numeric",
        month: "long",
      });
      const canCancel = b.status === "pending" || b.status === "confirmed";
      return `
      <div class="card booking-row">
        <div class="card-content">
          <div style="flex:1">
            <p class="service">${esc(b.service)}</p>
            <p class="when">${dateLabel} à ${b.start_time.slice(0, 5)} · ${b.duration_hours} h</p>
            <p class="address">${esc(b.address)}</p>
          </div>
          <div class="side">
            <span class="badge badge-secondary">${esc(STATUS_LABELS[b.status] || b.status)}</span>
            <span class="price">${euro(Number(b.price))}</span>
            <a class="btn btn-outline btn-sm rounded-full" href="pro.html?id=${encodeURIComponent(b.professional_id)}">Voir le pro</a>
            ${canCancel ? `<button type="button" class="btn btn-ghost btn-sm rounded-full" data-cancel="${esc(b.id)}">Annuler</button>` : ""}
          </div>
        </div>
      </div>`;
    })
    .join("");

  list.querySelectorAll("[data-cancel]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const id = btn.getAttribute("data-cancel");
      const { error } = await supabase.from("bookings").update({ status: "cancelled" }).eq("id", id);
      if (error) {
        toast.error("Annulation impossible.");
        return;
      }
      toast.success("Réservation annulée.");
      const bookings = await loadBookings();
      renderBookings(bookings);
    });
  });
}

document.addEventListener("DOMContentLoaded", async () => {
  const user = await requireAuth();
  if (!user) return;
  dashUserId = user.id;

  try {
    const bookings = await loadBookings();
    renderBookings(bookings);
  } catch (err) {
    console.error(err);
    document.getElementById("dashboard-loading").style.display = "none";
  }
});
