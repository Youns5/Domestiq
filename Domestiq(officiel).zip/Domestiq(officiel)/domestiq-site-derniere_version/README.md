# Domestiq — version HTML / CSS / JS

Marketplace de services à domicile. Trouvez un professionnel vérifié près de
chez vous, échangez, réservez et évaluez en toute confiance.

Ce dossier est une **conversion à l'identique** du site d'origine (qui était
en React 19 + TanStack Start + Tailwind CSS) vers du **HTML / CSS /
JavaScript simple**, sans framework, sans étape de build et sans
`node_modules`. Le rendu visuel et le comportement (comptes, recherche,
réservations, messagerie, favoris) sont les mêmes : le site continue
d'utiliser la même base **Supabase** (base de données, authentification,
temps réel) que la version d'origine.

## Comment l'ouvrir

Aucune installation n'est nécessaire. Deux façons de le lancer :

1. **Le plus simple** : double-cliquez sur `index.html` pour l'ouvrir dans
   votre navigateur.
2. **Recommandé** (évite quelques limitations des navigateurs avec les
   fichiers locaux) : lancez un petit serveur local depuis ce dossier, par
   exemple :

   ```sh
   python3 -m http.server 8080
   ```

   puis ouvrez `http://localhost:8080` dans votre navigateur.

Vous pouvez aussi déposer tout le dossier tel quel sur n'importe quel
hébergement de fichiers statiques (Netlify, Vercel, GitHub Pages, un simple
FTP, etc.) : il n'y a rien à compiler.

## Structure du projet

```
index.html              Page d'accueil
recherche.html           Recherche de professionnels (filtres, tri)
pro.html                 Fiche d'un professionnel (?id=...)
auth.html                 Connexion / inscription
tableau-de-bord.html     Mes réservations (page protégée)
favoris.html              Mes favoris (page protégée)
messages.html             Messagerie (page protégée, temps réel)
404.html                  Page introuvable

css/
└── styles.css            Toute la feuille de style (charte graphique,
                           composants boutons/cartes/badges, mises en page)

js/
├── supabase-client.js     Connexion à Supabase (URL + clé publique)
├── queries.js              Fonctions de lecture/écriture en base + utilitaires
├── icons.js                 Icônes SVG (mêmes tracés que l'original)
├── toast.js                  Petites notifications ("Réservation annulée", etc.)
├── header.js                 En-tête, pied de page, menu "Mon compte", garde
│                              d'accès des pages protégées
├── page-home.js              Logique de la page d'accueil
├── page-recherche.js         Logique de la page de recherche
├── page-auth.js               Logique connexion/inscription
├── page-pro.js                 Logique de la fiche professionnel (favoris,
│                                contact, réservation)
├── page-dashboard.js           Logique du tableau de bord
├── page-favoris.js             Logique des favoris
└── page-messages.js            Logique de la messagerie (avec mises à jour
                                 en temps réel via Supabase Realtime)

assets/
└── favicon.ico

robots.txt
```

Chaque page HTML charge, dans l'ordre : la librairie Supabase (via CDN), puis
`icons.js`, `supabase-client.js`, `queries.js`, `toast.js`, `header.js`, puis
le script propre à la page. Pas d'étape de compilation : vous pouvez modifier
n'importe quel fichier `.html`, `.css` ou `.js` et recharger la page pour
voir le résultat.

## Base de données et comptes

Le site reste connecté au **même projet Supabase** que la version d'origine
(les identifiants — URL et clé publique "publishable" — sont déjà dans
`js/supabase-client.js`). Cela veut dire que :

- les comptes existants fonctionnent toujours ;
- les mêmes professionnels, réservations, avis, favoris et conversations
  s'affichent ;
- toute nouvelle inscription, réservation ou message est enregistré au même
  endroit qu'avant.

Aucune clé secrète n'est utilisée ici : uniquement la clé publique
("publishable"), prévue pour être exposée dans un navigateur — c'est la même
que celle utilisée par le site React d'origine.

Le schéma de la base (tables, règles de sécurité RLS, données) n'a pas
changé ; si un jour vous voulez le retrouver ou le modifier, il vit toujours
dans `supabase/migrations/` du projet d'origine.

## Pages protégées

`tableau-de-bord.html`, `favoris.html` et `messages.html` vérifient qu'un
utilisateur est bien connecté avant de s'afficher (comme le faisait la route
`_authenticated` du site React) : sans session active, vous êtes redirigé
automatiquement vers `auth.html`.

## Ce qui n'a pas été repris

Le header et la page d'accueil contiennent des liens vers « Devenir
professionnel » (`espace-pro.html`) et « Administration » (`admin.html`) :
ces pages n'existaient déjà pas dans le site d'origine (elles renvoyaient une
404), elles ne sont donc pas non plus créées ici, pour ne rien changer au
comportement actuel.
