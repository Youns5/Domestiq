// Page d'accueil — équivalent de src/routes/index.tsx

function renderCategories(categories) {
  const el = document.getElementById("categories-grid");
  el.innerHTML = categories
    .map(
      (c) => `
      <a href="recherche.html?category=${encodeURIComponent(c.id)}" class="category-card">
        <span class="emoji">${esc(c.emoji)}</span>
        <p>${esc(c.name)}</p>
      </a>`,
    )
    .join("");
}

function renderTopPros(pros) {
  const el = document.getElementById("top-pros-grid");
  el.innerHTML = pros
    .slice(0, 6)
    .map(
      (p) => `
      <a href="pro.html?id=${encodeURIComponent(p.id)}">
        <div class="card card-hover pro-card" style="height:100%">
          <div class="card-content">
            <div class="pro-card-head">
              <div class="avatar-circle avatar-sm">${esc(initials(p.first_name, p.last_name))}</div>
              <div>
                <p class="name">${esc(p.first_name)} ${esc((p.last_name || "").charAt(0))}.</p>
                <p class="headline">${esc(p.headline)}</p>
              </div>
            </div>
            <p class="bio">${esc(p.bio)}</p>
            <div class="meta-row">
              <span class="rating">${icon("star")} ${Number(p.rating).toFixed(1)} <span style="color:var(--muted-foreground)">(${p.reviews_count})</span></span>
              <span class="price">${euro(Number(p.hourly_rate))}/h</span>
            </div>
            <p class="city">${icon("mapPin")} ${esc(p.city)}</p>
          </div>
        </div>
      </a>`,
    )
    .join("");
}

document.addEventListener("DOMContentLoaded", async () => {
  document.querySelectorAll("[data-icon]").forEach((el) => {
    el.innerHTML = icon(el.getAttribute("data-icon"));
  });

  const form = document.getElementById("hero-search-form");
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const q = document.getElementById("hero-q").value.trim();
    const city = document.getElementById("hero-city").value.trim();
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (city) params.set("city", city);
    window.location.href = "recherche.html" + (params.toString() ? `?${params}` : "");
  });

  try {
    const [categories, pros] = await Promise.all([fetchCategories(), fetchPros({ sort: "rating" })]);
    renderCategories(categories);
    renderTopPros(pros);
  } catch (err) {
    console.error(err);
  }
});
