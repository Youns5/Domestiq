// Utilitaires et requêtes Supabase — équivalent de src/lib/queries.ts

const PRO_FIELDS =
  "id,user_id,first_name,last_name,category_id,headline,bio,city,hourly_rate,min_hours,experience_years,languages,verified,rating,reviews_count,radius_km";

const WEEKDAYS = ["Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"];

const STATUS_LABELS = {
  pending: "En attente",
  confirmed: "Confirmée",
  refused: "Refusée",
  completed: "Terminée",
  cancelled: "Annulée",
};

function euro(n) {
  return new Intl.NumberFormat("fr-FR", { style: "currency", currency: "EUR" }).format(n);
}

function initials(first, last) {
  return `${(first || "").charAt(0)}${(last || "").charAt(0)}`.toUpperCase();
}

async function fetchCategories() {
  const { data, error } = await supabase.from("categories").select("*").order("sort_order");
  if (error) throw error;
  return data || [];
}

async function fetchPros(filters) {
  filters = filters || {};
  let req = supabase.from("professional_profiles").select(PRO_FIELDS).eq("published", true);

  if (filters.category) req = req.eq("category_id", filters.category);
  if (filters.city) req = req.ilike("city", `%${filters.city}%`);
  if (filters.maxRate) req = req.lte("hourly_rate", filters.maxRate);
  if (filters.minRating) req = req.gte("rating", filters.minRating);
  if (filters.q)
    req = req.or(
      `first_name.ilike.%${filters.q}%,last_name.ilike.%${filters.q}%,headline.ilike.%${filters.q}%,bio.ilike.%${filters.q}%`,
    );

  if (filters.sort === "price") req = req.order("hourly_rate", { ascending: true });
  else if (filters.sort === "experience") req = req.order("experience_years", { ascending: false });
  else req = req.order("rating", { ascending: false });

  const { data, error } = await req.limit(60);
  if (error) throw error;
  return data || [];
}

async function fetchProDetail(id) {
  const [pro, services, reviews, availability] = await Promise.all([
    supabase.from("professional_profiles").select(PRO_FIELDS).eq("id", id).maybeSingle(),
    supabase.from("services").select("*").eq("professional_id", id),
    supabase
      .from("reviews")
      .select("*")
      .eq("professional_id", id)
      .eq("flagged", false)
      .order("created_at", { ascending: false }),
    supabase.from("availability").select("*").eq("professional_id", id).order("weekday"),
  ]);
  if (pro.error) throw pro.error;
  return {
    pro: pro.data || null,
    services: services.data || [],
    reviews: reviews.data || [],
    availability: availability.data || [],
  };
}

function esc(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function getSearchParams() {
  return new URLSearchParams(window.location.search);
}
