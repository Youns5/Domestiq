// Page recherche — équivalent de src/routes/recherche.tsx

function readSearchState() {
  const sp = getSearchParams();
  return {
    q: sp.get("q") || undefined,
    city: sp.get("city") || undefined,
    category: sp.get("category") || undefined,
    maxRate: sp.get("maxRate") ? Number(sp.get("maxRate")) : undefined,
    minRating: sp.get("minRating") ? Number(sp.get("minRating")) : undefined,
    sort: sp.get("sort") || undefined,
  };
}

function writeSearchState(state) {
  const params = new URLSearchParams();
  Object.entries(state).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== "") params.set(k, v);
  });
  const qs = params.toString();
  window.history.pushState({}, "", qs ? `?${qs}` : window.location.pathname);
}

let searchState = readSearchState();
let categoriesCache = [];

function update(patch) {
  searchState = { ...searchState, ...patch };
  writeSearchState(searchState);
  renderFilters();
  loadResults();
}

function renderFilters() {
  document.getElementById("filter-q").value = searchState.q || "";
  document.getElementById("filter-city").value = searchState.city || "";
  document.getElementById("filter-max-rate").value = searchState.maxRate || 80;
  document.getElementById("filter-max-rate-label").textContent = searchState.maxRate
    ? euro(searchState.maxRate)
    : "—";
  document.getElementById("sort-select").value = searchState.sort || "rating";

  document.getElementById("category-chips").innerHTML = categoriesCache
    .map((c) => {
      const active = searchState.category === c.id;
      return `<button type="button" class="chip ${active ? "active" : ""}" data-cat="${esc(c.id)}">${esc(c.emoji)} ${esc(c.name)}</button>`;
    })
    .join("");
  document.querySelectorAll("#category-chips .chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-cat");
      update({ category: searchState.category === id ? undefined : id });
    });
  });

  const ratingOptions = [0, 3, 4, 4.5];
  document.getElementById("rating-chips").innerHTML = ratingOptions
    .map((r) => {
      const active = (searchState.minRating || 0) === r;
      return `<button type="button" class="chip ${active ? "active" : ""}" data-rating="${r}">${r === 0 ? "Toutes" : `${r}+`}</button>`;
    })
    .join("");
  document.querySelectorAll("#rating-chips .chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      const r = Number(btn.getAttribute("data-rating"));
      update({ minRating: r || undefined });
    });
  });
}

function renderResults(pros, loading) {
  document.getElementById("results-count").textContent = loading
    ? "Chargement…"
    : `${pros.length} professionnel(s)`;

  const grid = document.getElementById("results-grid");
  const empty = document.getElementById("results-empty");

  if (!loading && pros.length === 0) {
    grid.innerHTML = "";
    empty.style.display = "block";
    return;
  }
  empty.style.display = "none";

  grid.innerHTML = pros
    .map(
      (p) => `
      <a href="pro.html?id=${encodeURIComponent(p.id)}">
        <div class="card card-hover pro-card" style="height:100%">
          <div class="card-content">
            <div class="pro-card-head">
              <div class="avatar-circle avatar-sm">${esc(initials(p.first_name, p.last_name))}</div>
              <div>
                <p class="name">${esc(p.first_name)} ${esc((p.last_name || "").charAt(0))}.${p.verified ? icon("badgeCheck") : ""}</p>
                <p class="headline">${esc(p.headline)}</p>
              </div>
            </div>
            <p class="bio">${esc(p.bio)}</p>
            <div class="meta-row">
              <span class="rating">${icon("star")} ${Number(p.rating).toFixed(1)} <span style="color:var(--muted-foreground)">(${p.reviews_count})</span></span>
              <span class="price">${euro(Number(p.hourly_rate))}/h</span>
            </div>
            <p class="city">${icon("mapPin")} ${esc(p.city)} · ${p.experience_years} ans d'exp.</p>
          </div>
        </div>
      </a>`,
    )
    .join("");
}

async function loadResults() {
  renderResults([], true);
  try {
    const pros = await fetchPros(searchState);
    renderResults(pros, false);
  } catch (err) {
    console.error(err);
    renderResults([], false);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("filter-q").addEventListener("input", (e) =>
    update({ q: e.target.value || undefined }),
  );
  document.getElementById("filter-city").addEventListener("input", (e) =>
    update({ city: e.target.value || undefined }),
  );
  document.getElementById("filter-max-rate").addEventListener("input", (e) =>
    update({ maxRate: Number(e.target.value) }),
  );
  document.getElementById("sort-select").addEventListener("change", (e) =>
    update({ sort: e.target.value }),
  );
  document.getElementById("reset-filters").addEventListener("click", () => {
    searchState = {};
    writeSearchState(searchState);
    renderFilters();
    loadResults();
  });

  try {
    categoriesCache = await fetchCategories();
  } catch (err) {
    console.error(err);
  }
  renderFilters();
  loadResults();
});
