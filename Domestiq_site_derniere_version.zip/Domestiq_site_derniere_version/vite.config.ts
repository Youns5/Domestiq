import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import { tanstackStart } from "@tanstack/react-start/plugin/vite";
import tailwindcss from "@tailwindcss/vite";
import netlify from "@netlify/vite-plugin-tanstack-start";

export default defineConfig({
  resolve: {
    // Resolves the `@/*` path alias from tsconfig.json (native in Vite 8).
    tsconfigPaths: true,
  },
  plugins: [
    tanstackStart({
      // Redirect TanStack Start's bundled server entry to src/server.ts (our SSR error wrapper).
      // `vite build` ships from this entry.
      server: { entry: "server" },
    }),
    react(),
    tailwindcss(),
    // Builds the TanStack Start server as a Netlify function when running
    // `vite build` on Netlify (see netlify.toml).
    netlify({
      // L'application n'utilise pas d'Edge Functions Netlify : on désactive
      // leur émulation locale (qui exigerait Deno) pour un `vite dev` léger.
      dev: { edgeFunctions: { enabled: false } },
    }),
  ],
});
