import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search, ShieldCheck, Star, Clock, MapPin } from "lucide-react";
import { AppHeader, AppFooter } from "@/components/AppHeader";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { categoriesQuery, prosQuery, euro, initials } from "@/lib/queries";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Domestiq — Services à domicile de confiance" },
      {
        name: "description",
        content:
          "Trouvez un professionnel vérifié près de chez vous : ménage, jardinage, bricolage, garde d'enfants, cours particuliers. Réservation en quelques clics.",
      },
      { property: "og:title", content: "Domestiq — Services à domicile de confiance" },
      {
        property: "og:description",
        content: "La marketplace qui relie particuliers et professionnels des services à domicile.",
      },
    ],
  }),
  component: Home,
});

function Home() {
  const navigate = useNavigate();
  const [q, setQ] = useState("");
  const [city, setCity] = useState("");
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: pros = [] } = useQuery(prosQuery({ sort: "rating" }));

  return (
    <div className="min-h-screen">
      <AppHeader />

      <section className="hero-gradient">
        <div className="mx-auto max-w-6xl px-4 pb-20 pt-16 md:pt-24">
          <p className="mb-4 inline-flex items-center gap-2 rounded-full border border-border bg-background/70 px-3 py-1 text-xs font-medium text-muted-foreground">
            <ShieldCheck className="size-3.5 text-primary" /> Professionnels vérifiés et évalués
          </p>
          <h1 className="font-display max-w-3xl text-4xl font-bold leading-tight md:text-6xl">
            Le bon professionnel pour votre maison, en quelques minutes.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-muted-foreground">
            Ménage, jardinage, bricolage, garde d'enfants, cours particuliers… Comparez, échangez et
            réservez en toute confiance.
          </p>

          <form
            className="glass mt-8 flex flex-col gap-3 rounded-2xl p-3 md:flex-row"
            onSubmit={(e) => {
              e.preventDefault();
              navigate({ to: "/recherche", search: { q: q || undefined, city: city || undefined } });
            }}
          >
            <div className="flex flex-1 items-center gap-2 rounded-xl bg-background px-3">
              <Search className="size-4 text-muted-foreground" />
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Quel service cherchez-vous ?"
                className="border-0 shadow-none focus-visible:ring-0"
              />
            </div>
            <div className="flex flex-1 items-center gap-2 rounded-xl bg-background px-3">
              <MapPin className="size-4 text-muted-foreground" />
              <Input
                value={city}
                onChange={(e) => setCity(e.target.value)}
                placeholder="Votre ville"
                className="border-0 shadow-none focus-visible:ring-0"
              />
            </div>
            <Button type="submit" size="lg" className="rounded-xl">
              Rechercher
            </Button>
          </form>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <h2 className="font-display text-2xl font-bold">Explorer par catégorie</h2>
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {categories.map((c) => (
            <Link
              key={c.id}
              to="/recherche"
              search={{ category: c.id }}
              className="rounded-2xl border border-border bg-card p-4 transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-lg"
            >
              <span className="text-2xl">{c.emoji}</span>
              <p className="mt-2 font-medium">{c.name}</p>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="flex items-end justify-between">
          <h2 className="font-display text-2xl font-bold">Les mieux notés près de chez vous</h2>
          <Link to="/recherche" className="text-sm font-medium text-primary hover:underline">
            Voir tout
          </Link>
        </div>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {pros.slice(0, 6).map((p) => (
            <Link key={p.id} to="/pro/$id" params={{ id: p.id }}>
              <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-lg">
                <CardContent className="p-5">
                  <div className="flex items-center gap-3">
                    <div className="flex size-12 items-center justify-center rounded-full bg-primary/10 font-display font-bold text-primary">
                      {initials(p.first_name, p.last_name)}
                    </div>
                    <div>
                      <p className="font-semibold">
                        {p.first_name} {p.last_name.charAt(0)}.
                      </p>
                      <p className="text-sm text-muted-foreground">{p.headline}</p>
                    </div>
                  </div>
                  <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{p.bio}</p>
                  <div className="mt-4 flex items-center justify-between text-sm">
                    <span className="inline-flex items-center gap-1">
                      <Star className="size-4 fill-accent text-accent" />
                      {p.rating.toFixed(1)}
                      <span className="text-muted-foreground">({p.reviews_count})</span>
                    </span>
                    <span className="font-semibold">{euro(p.hourly_rate)}/h</span>
                  </div>
                  <p className="mt-2 inline-flex items-center gap-1 text-xs text-muted-foreground">
                    <MapPin className="size-3.5" /> {p.city}
                  </p>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <h2 className="font-display text-2xl font-bold">Comment ça marche ?</h2>
        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {[
            { icon: Search, t: "Cherchez", d: "Filtrez par métier, ville, tarif et note." },
            { icon: Clock, t: "Réservez", d: "Choisissez une date et un créneau disponible." },
            { icon: ShieldCheck, t: "Évaluez", d: "Notez la prestation une fois terminée." },
          ].map((s) => (
            <Card key={s.t}>
              <CardContent className="p-6">
                <s.icon className="size-6 text-primary" />
                <h3 className="mt-3 text-lg font-semibold">{s.t}</h3>
                <p className="mt-1 text-sm text-muted-foreground">{s.d}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-4">
        <div className="glass flex flex-col items-start gap-4 rounded-3xl p-8 md:flex-row md:items-center md:justify-between">
          <div>
            <h2 className="font-display text-2xl font-bold">Vous êtes professionnel ?</h2>
            <p className="mt-1 text-muted-foreground">
              Créez votre fiche gratuitement et recevez des demandes près de chez vous.
            </p>
          </div>
          <Button asChild size="lg" className="rounded-full">
            {/* Route prévue (page non encore implémentée) — cast pour conserver le typage strict */}
            <Link to={"/espace-pro" as "/"}>Créer ma fiche pro</Link>
          </Button>
        </div>
      </section>

      <AppFooter />
    </div>
  );
}
