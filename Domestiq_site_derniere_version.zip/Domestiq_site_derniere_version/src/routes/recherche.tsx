import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Star, MapPin, BadgeCheck } from "lucide-react";
import { AppHeader, AppFooter } from "@/components/AppHeader";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { categoriesQuery, prosQuery, euro, initials } from "@/lib/queries";

type SearchParams = {
  q?: string | undefined;
  city?: string | undefined;
  category?: string | undefined;
  maxRate?: number | undefined;
  minRating?: number | undefined;
  sort?: string | undefined;
};

export const Route = createFileRoute("/recherche")({
  validateSearch: (search: Record<string, unknown>): SearchParams => ({
    q: typeof search["q"] === "string" ? search["q"] : undefined,
    city: typeof search["city"] === "string" ? search["city"] : undefined,
    category: typeof search["category"] === "string" ? search["category"] : undefined,
    maxRate: search["maxRate"] ? Number(search["maxRate"]) : undefined,
    minRating: search["minRating"] ? Number(search["minRating"]) : undefined,
    sort: typeof search["sort"] === "string" ? search["sort"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Rechercher un professionnel — Domestiq" },
      {
        name: "description",
        content:
          "Comparez les professionnels des services à domicile : tarif horaire, note, expérience et ville.",
      },
      { property: "og:title", content: "Rechercher un professionnel — Domestiq" },
      {
        property: "og:description",
        content: "Filtrez par métier, ville, tarif et note pour trouver le bon pro.",
      },
    ],
  }),
  component: SearchPage,
});

function SearchPage() {
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/recherche" });
  const { data: categories = [] } = useQuery(categoriesQuery);
  const { data: pros = [], isLoading } = useQuery(prosQuery(search));

  const update = (patch: Partial<SearchParams>) =>
    navigate({ search: (prev) => ({ ...prev, ...patch }) });

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-6xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Trouver un professionnel</h1>

        <div className="mt-6 grid gap-6 lg:grid-cols-[260px_1fr]">
          <aside className="space-y-5 rounded-2xl border border-border bg-card p-5">
            <div className="space-y-1.5">
              <Label>Mot-clé</Label>
              <Input
                value={search.q ?? ""}
                onChange={(e) => update({ q: e.target.value || undefined })}
                placeholder="ménage, jardin…"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Ville</Label>
              <Input
                value={search.city ?? ""}
                onChange={(e) => update({ city: e.target.value || undefined })}
                placeholder="Paris"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Catégorie</Label>
              <div className="flex flex-wrap gap-1.5">
                {categories.map((c) => (
                  <button
                    key={c.id}
                    onClick={() =>
                      update({ category: search.category === c.id ? undefined : c.id })
                    }
                    className={`rounded-full border px-3 py-1 text-xs transition-colors ${
                      search.category === c.id
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border hover:border-primary/40"
                    }`}
                  >
                    {c.emoji} {c.name}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label>Tarif horaire max : {search.maxRate ? euro(search.maxRate) : "—"}</Label>
              <input
                type="range"
                min={10}
                max={80}
                step={5}
                value={search.maxRate ?? 80}
                onChange={(e) => update({ maxRate: Number(e.target.value) })}
                className="w-full accent-[hsl(var(--primary))]"
              />
            </div>
            <div className="space-y-1.5">
              <Label>Note minimum</Label>
              <div className="flex gap-1.5">
                {[0, 3, 4, 4.5].map((r) => (
                  <button
                    key={r}
                    onClick={() => update({ minRating: r || undefined })}
                    className={`rounded-full border px-3 py-1 text-xs ${
                      (search.minRating ?? 0) === r
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border"
                    }`}
                  >
                    {r === 0 ? "Toutes" : `${r}+`}
                  </button>
                ))}
              </div>
            </div>
            <Button
              variant="ghost"
              className="w-full"
              onClick={() => navigate({ search: {} })}
            >
              Réinitialiser
            </Button>
          </aside>

          <section>
            <div className="mb-4 flex items-center justify-between">
              <p className="text-sm text-muted-foreground">
                {isLoading ? "Chargement…" : `${pros.length} professionnel(s)`}
              </p>
              <select
                value={search.sort ?? "rating"}
                onChange={(e) => update({ sort: e.target.value })}
                className="rounded-full border border-border bg-background px-3 py-1.5 text-sm"
              >
                <option value="rating">Mieux notés</option>
                <option value="price">Prix croissant</option>
                <option value="experience">Plus expérimentés</option>
              </select>
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              {pros.map((p) => (
                <Link key={p.id} to="/pro/$id" params={{ id: p.id }}>
                  <Card className="h-full transition-all hover:-translate-y-0.5 hover:shadow-lg">
                    <CardContent className="p-5">
                      <div className="flex items-center gap-3">
                        <div className="font-display flex size-12 items-center justify-center rounded-full bg-primary/10 font-bold text-primary">
                          {initials(p.first_name, p.last_name)}
                        </div>
                        <div>
                          <p className="flex items-center gap-1 font-semibold">
                            {p.first_name} {p.last_name.charAt(0)}.
                            {p.verified && <BadgeCheck className="size-4 text-primary" />}
                          </p>
                          <p className="text-sm text-muted-foreground">{p.headline}</p>
                        </div>
                      </div>
                      <p className="mt-3 line-clamp-2 text-sm text-muted-foreground">{p.bio}</p>
                      <div className="mt-4 flex items-center justify-between text-sm">
                        <span className="inline-flex items-center gap-1">
                          <Star className="size-4 fill-accent text-accent" />
                          {p.rating.toFixed(1)}{" "}
                          <span className="text-muted-foreground">({p.reviews_count})</span>
                        </span>
                        <span className="font-semibold">{euro(p.hourly_rate)}/h</span>
                      </div>
                      <p className="mt-2 inline-flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="size-3.5" /> {p.city} · {p.experience_years} ans d'exp.
                      </p>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
            {!isLoading && pros.length === 0 && (
              <p className="rounded-2xl border border-dashed border-border p-10 text-center text-muted-foreground">
                Aucun professionnel ne correspond à vos critères.
              </p>
            )}
          </section>
        </div>
      </main>
      <AppFooter />
    </div>
  );
}
