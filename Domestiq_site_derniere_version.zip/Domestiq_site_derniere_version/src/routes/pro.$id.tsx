import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Star, MapPin, BadgeCheck, Heart, MessageSquare } from "lucide-react";
import { toast } from "sonner";
import { AppHeader, AppFooter } from "@/components/AppHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { proDetailQuery, euro, initials, WEEKDAYS } from "@/lib/queries";

export const Route = createFileRoute("/pro/$id")({
  head: () => ({
    meta: [
      { title: "Fiche professionnel — Domestiq" },
      {
        name: "description",
        content:
          "Découvrez le parcours, les prestations, les disponibilités et les avis de ce professionnel, puis réservez en ligne.",
      },
      { property: "og:title", content: "Fiche professionnel — Domestiq" },
      {
        property: "og:description",
        content: "Prestations, tarifs, disponibilités et avis vérifiés sur Domestiq.",
      },
    ],
  }),
  component: ProPage,
});

function ProPage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { userId } = useAuth();
  const { data, isLoading } = useQuery(proDetailQuery(id));

  const [service, setService] = useState("");
  const [date, setDate] = useState("");
  const [startTime, setStartTime] = useState("09:00");
  const [hours, setHours] = useState(2);
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [busy, setBusy] = useState(false);

  const { data: favorite } = useQuery({
    queryKey: ["favorite", id, userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data } = await supabase
        .from("favorites")
        .select("id")
        .eq("professional_id", id)
        .eq("user_id", userId!)
        .maybeSingle();
      return data?.id ?? null;
    },
  });

  if (isLoading) {
    return (
      <div className="min-h-screen">
        <AppHeader />
        <main className="mx-auto max-w-6xl px-4 py-16 text-muted-foreground">Chargement…</main>
      </div>
    );
  }

  const pro = data?.pro;
  if (!pro) {
    return (
      <div className="min-h-screen">
        <AppHeader />
        <main className="mx-auto max-w-6xl px-4 py-16">
          <h1 className="font-display text-2xl font-bold">Professionnel introuvable</h1>
          <Button asChild className="mt-6 rounded-full">
            <Link to="/recherche">Retour à la recherche</Link>
          </Button>
        </main>
        <AppFooter />
      </div>
    );
  }

  const price = Number(pro.hourly_rate) * hours;

  async function toggleFavorite() {
    if (!userId) return navigate({ to: "/auth" });
    if (favorite) {
      await supabase.from("favorites").delete().eq("id", favorite);
    } else {
      await supabase.from("favorites").insert({ user_id: userId, professional_id: id });
    }
    queryClient.invalidateQueries({ queryKey: ["favorite", id, userId] });
    queryClient.invalidateQueries({ queryKey: ["favorites"] });
  }

  async function startConversation() {
    if (!userId) return navigate({ to: "/auth" });
    const { data: existing } = await supabase
      .from("conversations")
      .select("id")
      .eq("client_id", userId)
      .eq("professional_id", id)
      .maybeSingle();
    if (!existing) {
      const { error } = await supabase
        .from("conversations")
        .insert({ client_id: userId, professional_id: id });
      if (error) return toast.error("Impossible d'ouvrir la discussion.");
    }
    navigate({ to: "/messages" });
  }

  async function book(e: React.FormEvent) {
    e.preventDefault();
    if (!userId) return navigate({ to: "/auth" });
    if (!service || !date || !address) {
      toast.error("Merci de compléter la prestation, la date et l'adresse.");
      return;
    }
    setBusy(true);
    const { error } = await supabase.from("bookings").insert({
      client_id: userId,
      professional_id: id,
      service,
      scheduled_date: date,
      start_time: startTime,
      duration_hours: hours,
      address,
      notes,
      price,
    });
    setBusy(false);
    if (error) return toast.error("La réservation n'a pas pu être enregistrée.");
    toast.success("Demande envoyée ! Le professionnel va la confirmer.");
    navigate({ to: "/tableau-de-bord" });
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto grid max-w-6xl gap-8 px-4 py-10 lg:grid-cols-[1.6fr_1fr]">
        <div className="space-y-6">
          <Card className="glass">
            <CardContent className="flex flex-col gap-4 p-6 sm:flex-row sm:items-start">
              <div className="flex size-20 shrink-0 items-center justify-center rounded-2xl bg-primary/10 font-display text-2xl font-bold text-primary">
                {initials(pro.first_name, pro.last_name)}
              </div>
              <div className="flex-1">
                <h1 className="font-display text-3xl font-bold">
                  {pro.first_name} {pro.last_name}
                  {pro.verified && (
                    <BadgeCheck className="ml-2 inline size-5 text-primary" aria-label="Vérifié" />
                  )}
                </h1>
                <p className="mt-1 text-muted-foreground">{pro.headline}</p>
                <div className="mt-3 flex flex-wrap items-center gap-3 text-sm text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Star className="size-4 fill-accent text-accent" />
                    {pro.rating} ({pro.reviews_count} avis)
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="size-4" />
                    {pro.city} · {pro.radius_km} km
                  </span>
                  <span>{pro.experience_years} ans d'expérience</span>
                </div>
                <div className="mt-4 flex flex-wrap gap-2">
                  <Button variant="outline" className="rounded-full" onClick={toggleFavorite}>
                    <Heart className={`mr-1 size-4 ${favorite ? "fill-primary text-primary" : ""}`} />
                    {favorite ? "Retiré des favoris" : "Ajouter aux favoris"}
                  </Button>
                  <Button variant="outline" className="rounded-full" onClick={startConversation}>
                    <MessageSquare className="mr-1 size-4" />
                    Contacter
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="font-display text-xl font-semibold">Présentation</h2>
              <p className="mt-2 whitespace-pre-line text-muted-foreground">{pro.bio}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {pro.languages.map((l: string) => (
                  <Badge key={l} variant="secondary">
                    {l}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="font-display text-xl font-semibold">Prestations</h2>
              <div className="mt-3 flex flex-wrap gap-2">
                {data.services.map((s: { id: string; name: string }) => (
                  <Badge key={s.id} variant="outline" className="rounded-full px-3 py-1">
                    {s.name}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="font-display text-xl font-semibold">Disponibilités</h2>
              <ul className="mt-3 grid gap-1 text-sm text-muted-foreground sm:grid-cols-2">
                {data.availability.map(
                  (a: {
                    id: string;
                    weekday: number;
                    start_time: string;
                    end_time: string;
                    available: boolean;
                  }) => (
                    <li key={a.id}>
                      <span className="font-medium text-foreground">{WEEKDAYS[a.weekday]}</span> ·{" "}
                      {a.available
                        ? `${a.start_time.slice(0, 5)} – ${a.end_time.slice(0, 5)}`
                        : "Indisponible"}
                    </li>
                  ),
                )}
              </ul>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <h2 className="font-display text-xl font-semibold">
                Avis ({data.reviews.length})
              </h2>
              <div className="mt-4 space-y-4">
                {data.reviews.length === 0 && (
                  <p className="text-sm text-muted-foreground">Aucun avis pour le moment.</p>
                )}
                {data.reviews.map(
                  (r: { id: string; author_name: string; rating: number; comment: string }) => (
                    <div key={r.id} className="rounded-xl border border-border/60 p-4">
                      <div className="flex items-center justify-between">
                        <span className="font-medium">{r.author_name}</span>
                        <span className="flex items-center gap-1 text-sm">
                          <Star className="size-4 fill-accent text-accent" />
                          {r.rating}/5
                        </span>
                      </div>
                      <p className="mt-2 text-sm text-muted-foreground">{r.comment}</p>
                    </div>
                  ),
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <aside>
          <Card className="glass sticky top-24">
            <CardContent className="p-6">
              <p className="font-display text-2xl font-bold">
                {euro(Number(pro.hourly_rate))}
                <span className="text-sm font-normal text-muted-foreground"> / heure</span>
              </p>
              <p className="text-sm text-muted-foreground">
                Minimum {pro.min_hours} h par intervention
              </p>
              <form className="mt-5 space-y-3" onSubmit={book}>
                <div>
                  <Label htmlFor="service">Prestation</Label>
                  <select
                    id="service"
                    value={service}
                    onChange={(e) => setService(e.target.value)}
                    className="mt-1 h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                  >
                    <option value="">Choisir…</option>
                    {data.services.map((s: { id: string; name: string }) => (
                      <option key={s.id} value={s.name}>
                        {s.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="date">Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="time">Heure</Label>
                    <Input
                      id="time"
                      type="time"
                      value={startTime}
                      onChange={(e) => setStartTime(e.target.value)}
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="hours">Durée (heures)</Label>
                  <Input
                    id="hours"
                    type="number"
                    min={Number(pro.min_hours)}
                    step="0.5"
                    value={hours}
                    onChange={(e) => setHours(Number(e.target.value))}
                  />
                </div>
                <div>
                  <Label htmlFor="address">Adresse d'intervention</Label>
                  <Input
                    id="address"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="12 rue de Rivoli, Paris"
                  />
                </div>
                <div>
                  <Label htmlFor="notes">Précisions</Label>
                  <Textarea
                    id="notes"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    rows={3}
                  />
                </div>
                <div className="flex items-center justify-between rounded-xl bg-secondary/60 px-4 py-3 text-sm">
                  <span>Total estimé</span>
                  <span className="font-display text-lg font-bold">{euro(price)}</span>
                </div>
                <Button type="submit" className="w-full rounded-full" disabled={busy}>
                  {busy ? "Envoi…" : "Demander une réservation"}
                </Button>
                <p className="text-center text-xs text-muted-foreground">
                  Paiement en ligne bientôt disponible. Aucun débit aujourd'hui.
                </p>
              </form>
            </CardContent>
          </Card>
        </aside>
      </main>
      <AppFooter />
    </div>
  );
}
