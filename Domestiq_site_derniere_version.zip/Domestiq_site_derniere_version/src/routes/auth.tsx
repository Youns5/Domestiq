import { useState } from "react";
import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { toast } from "sonner";

export const Route = createFileRoute("/auth")({
  head: () => ({
    meta: [
      { title: "Connexion et inscription — Domestiq" },
      {
        name: "description",
        content:
          "Créez votre compte Domestiq, particulier ou professionnel, pour réserver ou proposer des services à domicile.",
      },
      { property: "og:title", content: "Connexion et inscription — Domestiq" },
      {
        property: "og:description",
        content: "Rejoignez Domestiq et trouvez le bon professionnel près de chez vous.",
      },
    ],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [accountType, setAccountType] = useState<"particulier" | "professionnel">("particulier");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      if (mode === "signup") {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { first_name: firstName, last_name: lastName, account_type: accountType },
          },
        });
        if (error) throw error;
        if (!data.session) {
          setSent(true);
          return;
        }
        navigate({
          to: accountType === "professionnel" ? ("/espace-pro" as "/") : "/tableau-de-bord",
        });
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        navigate({ to: "/tableau-de-bord" });
      }
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Une erreur est survenue");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="hero-gradient flex min-h-screen flex-col items-center justify-center px-4 py-12">
      <Link to="/" className="font-display mb-6 text-2xl font-bold text-primary">
        Domestiq
      </Link>
      <Card className="glass w-full max-w-md">
        <CardContent className="p-6">
          {sent ? (
            <div className="space-y-3 text-center">
              <h1 className="font-display text-xl font-bold">Vérifiez votre boîte mail</h1>
              <p className="text-sm text-muted-foreground">
                Nous avons envoyé un lien de confirmation à {email}. Cliquez dessus pour activer
                votre compte.
              </p>
            </div>
          ) : (
            <>
              <div className="mb-6 flex rounded-full bg-secondary p-1 text-sm">
                {(["login", "signup"] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMode(m)}
                    className={`flex-1 rounded-full px-4 py-2 font-medium transition-colors ${
                      mode === m
                        ? "bg-primary text-primary-foreground"
                        : "text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {m === "login" ? "Connexion" : "Inscription"}
                  </button>
                ))}
              </div>

              <form onSubmit={submit} className="space-y-4">
                {mode === "signup" && (
                  <>
                    <div className="grid grid-cols-2 gap-2">
                      {(["particulier", "professionnel"] as const).map((t) => (
                        <button
                          key={t}
                          type="button"
                          onClick={() => setAccountType(t)}
                          className={`rounded-xl border p-3 text-left text-sm transition-colors ${
                            accountType === t
                              ? "border-primary bg-primary/5 text-foreground"
                              : "border-border text-muted-foreground hover:border-primary/40"
                          }`}
                        >
                          <span className="block font-semibold capitalize">{t}</span>
                          <span className="text-xs">
                            {t === "particulier" ? "Je cherche un service" : "Je propose mes services"}
                          </span>
                        </button>
                      ))}
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-1.5">
                        <Label htmlFor="fn">Prénom</Label>
                        <Input
                          id="fn"
                          value={firstName}
                          onChange={(e) => setFirstName(e.target.value)}
                          required
                        />
                      </div>
                      <div className="space-y-1.5">
                        <Label htmlFor="ln">Nom</Label>
                        <Input
                          id="ln"
                          value={lastName}
                          onChange={(e) => setLastName(e.target.value)}
                          required
                        />
                      </div>
                    </div>
                  </>
                )}
                <div className="space-y-1.5">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="pw">Mot de passe</Label>
                  <Input
                    id="pw"
                    type="password"
                    minLength={6}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                  />
                </div>
                <Button type="submit" className="w-full rounded-full" disabled={loading}>
                  {mode === "login" ? "Se connecter" : "Créer mon compte"}
                </Button>
              </form>

            </>
          )}
        </CardContent>
      </Card>
    </main>
  );
}
