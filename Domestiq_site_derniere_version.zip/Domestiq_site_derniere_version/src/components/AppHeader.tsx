import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { Menu, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Routes prévues (pages non encore implémentées) : le cast préserve le typage
// strict de l'API de navigation sans modifier l'interface actuelle.
const PLANNED_PRO_ROUTE = "/espace-pro" as "/";
const ADMIN_ROUTE = "/admin" as "/";

export function AppHeader() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  async function signOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="sticky top-0 z-50 border-b border-border/60 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-6xl items-center gap-4 px-4">
        <Link to="/" className="font-display text-xl font-bold tracking-tight text-primary">
          Domestiq
        </Link>
        <nav className="ml-4 hidden items-center gap-1 text-sm md:flex">
          <Link
            to="/recherche"
            className="rounded-full px-3 py-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            Rechercher un pro
          </Link>
          <Link
            to={PLANNED_PRO_ROUTE}
            className="rounded-full px-3 py-2 text-muted-foreground transition-colors hover:bg-secondary hover:text-foreground"
          >
            Devenir professionnel
          </Link>
        </nav>
        <div className="ml-auto flex items-center gap-2">
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" className="rounded-full">
                  <Menu className="mr-1 size-4" />
                  Mon compte
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuItem asChild>
                  <Link to="/tableau-de-bord">Mes réservations</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/messages">Messagerie</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to="/favoris">Favoris</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to={PLANNED_PRO_ROUTE}>Espace professionnel</Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link to={ADMIN_ROUTE}>Administration</Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={signOut}>Se déconnecter</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <>
              <Button asChild variant="ghost" className="rounded-full">
                <Link to="/auth">Se connecter</Link>
              </Button>
              <Button asChild className="rounded-full">
                <Link to="/auth" search={{ mode: "signup" }}>
                  <Sparkles className="mr-1 size-4" />
                  Créer un compte
                </Link>
              </Button>
            </>
          )}
        </div>
      </div>
    </header>
  );
}

export function AppFooter() {
  return (
    <footer className="mt-24 border-t border-border/60 bg-secondary/40">
      <div className="mx-auto flex max-w-6xl flex-col gap-2 px-4 py-10 text-sm text-muted-foreground">
        <span className="font-display text-lg font-bold text-primary">Domestiq</span>
        <p>La marketplace des services à domicile de confiance.</p>
        <p className="text-xs">© {new Date().getFullYear()} Domestiq — Tous droits réservés.</p>
      </div>
    </footer>
  );
}
