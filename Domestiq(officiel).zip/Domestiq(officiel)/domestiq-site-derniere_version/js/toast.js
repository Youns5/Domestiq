// Notifications "toast" — équivalent léger de la librairie sonner utilisée
// par le site d'origine.
const toast = {
  _stack() {
    let el = document.querySelector(".toast-stack");
    if (!el) {
      el = document.createElement("div");
      el.className = "toast-stack";
      document.body.appendChild(el);
    }
    return el;
  },
  _show(message, type) {
    const stack = this._stack();
    const el = document.createElement("div");
    el.className = `toast ${type}`;
    el.textContent = message;
    stack.appendChild(el);
    setTimeout(() => el.remove(), 4000);
  },
  success(message) {
    this._show(message, "success");
  },
  error(message) {
    this._show(message, "error");
  },
};
