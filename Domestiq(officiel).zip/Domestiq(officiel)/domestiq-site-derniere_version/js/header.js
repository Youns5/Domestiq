// En-tête / pied de page communs — équivalent de AppHeader.tsx, AppFooter.tsx
// et du hook useAuth.ts.

function renderHeader() {
  const el = document.getElementById("app-header");
  if (!el) return;
  el.innerHTML = `
    <div class="app-header__inner">
      <a href="index.html" class="app-header__logo">Domestiq</a>
      <nav class="app-header__nav">
        <a href="recherche.html">Rechercher un pro</a>
        <a href="espace-pro.html">Devenir professionnel</a>
      </nav>
      <div class="app-header__actions" id="header-actions"></div>
    </div>
  `;
  renderHeaderActions(null);

  supabase.auth.onAuthStateChange((_event, session) => {
    renderHeaderActions(session ? session.user : null);
  });
  supabase.auth.getSession().then(({ data }) => {
    renderHeaderActions(data.session ? data.session.user : null);
  });
}

function renderHeaderActions(user) {
  const actions = document.getElementById("header-actions");
  if (!actions) return;

  if (user) {
    actions.innerHTML = `
      <div class="dropdown" id="account-dropdown">
        <button type="button" class="btn btn-outline rounded-full" id="account-trigger">
          ${icon("menu", "")} Mon compte
        </button>
        <div class="dropdown-content">
          <a href="tableau-de-bord.html" class="dropdown-item">Mes réservations</a>
          <a href="messages.html" class="dropdown-item">Messagerie</a>
          <a href="favoris.html" class="dropdown-item">Favoris</a>
          <a href="espace-pro.html" class="dropdown-item">Espace professionnel</a>
          <a href="admin.html" class="dropdown-item">Administration</a>
          <div class="dropdown-separator"></div>
          <button type="button" class="dropdown-item" id="sign-out-btn">Se déconnecter</button>
        </div>
      </div>
    `;
    const dropdown = document.getElementById("account-dropdown");
    const trigger = document.getElementById("account-trigger");
    trigger.addEventListener("click", (e) => {
      e.stopPropagation();
      dropdown.classList.toggle("open");
    });
    document.addEventListener("click", () => dropdown.classList.remove("open"));

    document.getElementById("sign-out-btn").addEventListener("click", async () => {
      await supabase.auth.signOut();
      window.location.href = "auth.html";
    });
  } else {
    actions.innerHTML = `
      <a href="auth.html" class="btn btn-ghost rounded-full">Se connecter</a>
      <a href="auth.html?mode=signup" class="btn btn-default rounded-full">
        ${icon("sparkles", "")} Créer un compte
      </a>
    `;
  }
}

function renderFooter() {
  const el = document.getElementById("app-footer");
  if (!el) return;
  el.innerHTML = `
    <div class="app-footer__inner">
      <span class="app-footer__logo">Domestiq</span>
      <p>La marketplace des services à domicile de confiance.</p>
      <p style="font-size:.75rem">© ${new Date().getFullYear()} Domestiq — Tous droits réservés.</p>
    </div>
  `;
}

// Garde d'accès pour les pages "_authenticated" (favoris, messages,
// tableau de bord) : redirige vers /auth si aucune session active.
async function requireAuth() {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) {
    window.location.href = "auth.html";
    return null;
  }
  return data.user;
}

document.addEventListener("DOMContentLoaded", () => {
  renderHeader();
  renderFooter();
});
