// Signalement d'erreur côté client (boundary d'erreur React + pages SSR).
export function reportAppError(error: unknown, context: Record<string, unknown> = {}) {
  // La production ne relance pas les erreurs capturées par les boundaries vers
  // window.onerror, donc on logge explicitement avec un maximum de contexte.
  const message =
    error instanceof Response
      ? `Response ${error.status}${error.url ? ` at ${error.url}` : ""}`
      : error instanceof Error
        ? error.message
        : String(error);
  const stack = error instanceof Error ? error.stack : undefined;
  console.error("[app-error]", message, {
    route: typeof window !== "undefined" ? window.location.pathname : undefined,
    ...context,
    ...(stack !== undefined && { stack }),
  });
}
