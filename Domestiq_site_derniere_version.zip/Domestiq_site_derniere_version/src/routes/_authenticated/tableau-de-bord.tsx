import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppHeader, AppFooter } from "@/components/AppHeader";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { euro, STATUS_LABELS } from "@/lib/queries";

export const Route = createFileRoute("/_authenticated/tableau-de-bord")({
  head: () => ({
    meta: [
      { title: "Mes réservations — Domestiq" },
      {
        name: "description",
        content: "Suivez vos demandes de prestations à domicile et leur statut sur Domestiq.",
      },
      { property: "og:title", content: "Mes réservations — Domestiq" },
      { property: "og:description", content: "Vos prestations à domicile en un coup d'œil." },
    ],
  }),
  component: DashboardPage,
});

type Booking = {
  id: string;
  service: string;
  scheduled_date: string;
  start_time: string;
  duration_hours: number;
  address: string;
  price: number;
  status: string;
  professional_id: string;
  client_id: string;
};

function DashboardPage() {
  const { userId } = useAuth();
  const queryClient = useQueryClient();

  const { data: bookings = [], isLoading } = useQuery({
    queryKey: ["bookings", userId],
    enabled: !!userId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .eq("client_id", userId!)
        .order("scheduled_date", { ascending: false });
      if (error) throw error;
      return data as Booking[];
    },
  });

  async function cancel(id: string) {
    const { error } = await supabase.from("bookings").update({ status: "cancelled" }).eq("id", id);
    if (error) {
      toast.error("Annulation impossible.");
      return;
    }
    toast.success("Réservation annulée.");
    queryClient.invalidateQueries({ queryKey: ["bookings", userId] });
  }

  return (
    <div className="min-h-screen">
      <AppHeader />
      <main className="mx-auto max-w-5xl px-4 py-10">
        <h1 className="font-display text-3xl font-bold">Mes réservations</h1>
        <p className="mt-1 text-muted-foreground">
          Retrouvez ici toutes vos demandes de prestations.
        </p>

        {isLoading && <p className="mt-8 text-muted-foreground">Chargement…</p>}

        {!isLoading && bookings.length === 0 && (
          <Card className="mt-8 glass">
            <CardContent className="p-8 text-center">
              <p className="text-muted-foreground">Vous n'avez encore aucune réservation.</p>
              <Button asChild className="mt-4 rounded-full">
                <Link to="/recherche">Trouver un professionnel</Link>
              </Button>
            </CardContent>
          </Card>
        )}

        <div className="mt-8 space-y-4">
          {bookings.map((b) => (
            <Card key={b.id}>
              <CardContent className="flex flex-col gap-3 p-5 sm:flex-row sm:items-center">
                <div className="flex-1">
                  <p className="font-display text-lg font-semibold">{b.service}</p>
                  <p className="text-sm text-muted-foreground">
                    {new Date(b.scheduled_date).toLocaleDateString("fr-FR", {
                      weekday: "long",
                      day: "numeric",
                      month: "long",
                    })}{" "}
                    à {b.start_time.slice(0, 5)} · {b.duration_hours} h
                  </p>
                  <p className="text-sm text-muted-foreground">{b.address}</p>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="secondary">{STATUS_LABELS[b.status] ?? b.status}</Badge>
                  <span className="font-display font-bold">{euro(Number(b.price))}</span>
                  <Button asChild variant="outline" size="sm" className="rounded-full">
                    <Link to="/pro/$id" params={{ id: b.professional_id }}>
                      Voir le pro
                    </Link>
                  </Button>
                  {(b.status === "pending" || b.status === "confirmed") && (
                    <Button
                      variant="ghost"
                      size="sm"
                      className="rounded-full"
                      onClick={() => cancel(b.id)}
                    >
                      Annuler
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </main>
      <AppFooter />
    </div>
  );
}
