// Page connexion/inscription — équivalent de src/routes/auth.tsx

let authMode = "login";
let accountType = "particulier";

function setMode(mode) {
  authMode = mode;
  document.querySelectorAll(".auth-tabs button").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.mode === mode);
  });
  document.getElementById("signup-fields").style.display = mode === "signup" ? "" : "none";
  document.getElementById("auth-submit").textContent =
    mode === "login" ? "Se connecter" : "Créer mon compte";
}

function setAccountType(type) {
  accountType = type;
  document.querySelectorAll(".account-type-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.type === type);
  });
}

document.addEventListener("DOMContentLoaded", () => {
  const sp = getSearchParams();
  if (sp.get("mode") === "signup") setMode("signup");
  else setMode("login");
  setAccountType("particulier");

  document.querySelectorAll(".auth-tabs button").forEach((btn) => {
    btn.addEventListener("click", () => setMode(btn.dataset.mode));
  });
  document.querySelectorAll(".account-type-btn").forEach((btn) => {
    btn.addEventListener("click", () => setAccountType(btn.dataset.type));
  });

  const form = document.getElementById("auth-form");
  const submitBtn = document.getElementById("auth-submit");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;

    const email = document.getElementById("auth-email").value;
    const password = document.getElementById("auth-password").value;

    try {
      if (authMode === "signup") {
        const firstName = document.getElementById("auth-firstname").value;
        const lastName = document.getElementById("auth-lastname").value;
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: window.location.origin,
            data: { first_name: firstName, last_name: lastName, account_type: accountType },
          },
        });
        if (error) throw error;
        if (!data.session) {
          document.getElementById("auth-card-body").innerHTML = `
            <div class="auth-sent">
              <h1>Vérifiez votre boîte mail</h1>
              <p>Nous avons envoyé un lien de confirmation à ${esc(email)}. Cliquez dessus pour activer votre compte.</p>
            </div>`;
          return;
        }
        window.location.href = accountType === "professionnel" ? "espace-pro.html" : "tableau-de-bord.html";
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        window.location.href = "tableau-de-bord.html";
      }
    } catch (err) {
      toast.error(err && err.message ? err.message : "Une erreur est survenue");
    } finally {
      submitBtn.disabled = false;
    }
  });
});
